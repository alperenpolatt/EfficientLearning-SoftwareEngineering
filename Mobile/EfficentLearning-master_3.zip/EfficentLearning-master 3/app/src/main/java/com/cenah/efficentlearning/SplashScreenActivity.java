package com.cenah.efficentlearning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import com.cenah.efficentlearning.helpers.Apm;
import com.cenah.efficentlearning.helpers.AuthMainPageIntent;

public class SplashScreenActivity extends AppCompatActivity {

    View rootView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        rootView = getWindow().getDecorView().getRootView();

        if (new Apm(getApplicationContext()).getSharedInfo() != null) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    new AuthMainPageIntent(new Apm(SplashScreenActivity.this).getSharedInfo().getUserRole(),SplashScreenActivity.this).Page();
                }
            }, 4000);
        } else {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    finish();
                    startActivity(new Intent(SplashScreenActivity.this, LoginActivity.class));
                }
            }, 4000);


        }
    }
}
