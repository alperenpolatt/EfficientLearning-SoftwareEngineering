package com.cenah.efficentlearning.models;

public class JoinClassModel {
    private int givenClassroomId;

    public JoinClassModel(int givenClassroomId) {
        this.givenClassroomId = givenClassroomId;
    }
}
