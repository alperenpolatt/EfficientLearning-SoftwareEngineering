package com.cenah.efficentlearning.models;

public class ScoreModel {

    private int userId;
    private String name;
    private String surname;
    private String username;
    private int totalScore;


    public ScoreModel() {
    }

    public ScoreModel(int userId, String name, String surname, String username, int totalScore) {
        this.userId = userId;
        this.name = name;
        this.surname = surname;
        this.username = username;
        this.totalScore = totalScore;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }
}
