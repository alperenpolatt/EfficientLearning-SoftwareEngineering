import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sco',
  templateUrl: './sco.component.html',
  styleUrls: ['./sco.component.css']
})
export class ScoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
