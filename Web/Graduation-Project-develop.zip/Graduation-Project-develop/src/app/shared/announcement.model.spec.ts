import { Announcement } from './announcement.model';

describe('Announcement', () => {
  it('should create an instance', () => {
    expect(new Announcement()).toBeTruthy();
  });
});
