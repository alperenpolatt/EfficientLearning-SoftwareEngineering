export class Announcement {

    givenClassroomId: Number;
    description: string;
}
