import { Classroom } from './classroom.model';

describe('Classroom', () => {
  it('should create an instance', () => {
    expect(new Classroom()).toBeTruthy();
  });
});
