export class Classroom {
    id: Number;
    courseId: Number;
    description: string;
    content: string;
}
