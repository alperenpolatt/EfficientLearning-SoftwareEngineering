export class Comment {
    announcementId: Number;
    description: string;
}
