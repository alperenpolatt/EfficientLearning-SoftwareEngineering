export class Course {
    id: number;
    name: string;
    programmingType: string;

}
