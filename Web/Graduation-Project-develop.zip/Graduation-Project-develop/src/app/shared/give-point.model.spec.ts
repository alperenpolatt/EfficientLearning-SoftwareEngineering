import { GivePoint } from './give-point.model';

describe('GivePoint', () => {
  it('should create an instance', () => {
    expect(new GivePoint()).toBeTruthy();
  });
});
