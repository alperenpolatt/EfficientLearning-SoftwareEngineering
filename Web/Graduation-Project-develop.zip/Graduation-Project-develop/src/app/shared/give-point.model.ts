export class GivePoint {
    userId:Number;
    materialId:Number;
    score:Number;
}
