import { MaterialAnswer } from './material-answer.model';

describe('MaterialAnswer', () => {
  it('should create an instance', () => {
    expect(new MaterialAnswer()).toBeTruthy();
  });
});
