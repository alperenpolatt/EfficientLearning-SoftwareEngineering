export class MaterialAnswer {
    materialId: Number;
    answer: string;
}
