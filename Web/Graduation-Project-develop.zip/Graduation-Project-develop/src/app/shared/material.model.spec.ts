import { Material } from './material.model';

describe('Material', () => {
  it('should create an instance', () => {
    expect(new Material()).toBeTruthy();
  });
});
