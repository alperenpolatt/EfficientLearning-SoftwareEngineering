export class Material {
    
    givenClassroomId: Number;
    materialType: Number;
    materialScale: Number;
    question: string;
    hint: string;
    description: string;
    deadline: Date;

}
