export class Student {  
    id: number;
    username: string;
    name: string;
    surname: string;
    email: string;
    password: string;
    confirmPassword:string;
}
