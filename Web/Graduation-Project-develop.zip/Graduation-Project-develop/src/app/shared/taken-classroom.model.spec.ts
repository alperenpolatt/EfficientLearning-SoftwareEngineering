import { TakenClassroom } from './taken-classroom.model';

describe('TakenClassroom', () => {
  it('should create an instance', () => {
    expect(new TakenClassroom()).toBeTruthy();
  });
});
