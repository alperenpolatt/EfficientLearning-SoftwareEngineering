export class TakenClassroom {
    givenClassroomId: Number;
}
