export class Teacher {
    id: number;
    name: string;
    surname: string;
    username: string;
    email: string;
    password: string;
    confirmPassword: string;
}
