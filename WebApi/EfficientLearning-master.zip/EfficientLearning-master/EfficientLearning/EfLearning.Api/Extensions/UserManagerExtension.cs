﻿namespace EfLearning.Api.Extensions
{
    public static class UserManagerExtension
    {

    }
}
