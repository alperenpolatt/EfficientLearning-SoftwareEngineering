﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EfLearning.Business.Common
{
    public static class UserPracticeTotalScore
    {
        public static int Score { get; set; } = 100;
    }
}
