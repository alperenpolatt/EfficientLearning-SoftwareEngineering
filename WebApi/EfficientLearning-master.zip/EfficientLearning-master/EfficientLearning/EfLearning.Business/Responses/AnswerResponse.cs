﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EfLearning.Business.Responses
{
    public class AnswerResponse
    {
        public bool AnswerSuccess { get; set; }
    }
}
