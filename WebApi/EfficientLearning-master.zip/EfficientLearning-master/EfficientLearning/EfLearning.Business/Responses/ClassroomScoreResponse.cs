﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EfLearning.Business.Responses
{
    public class ClassroomScoreResponse
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Username { get; set; }
        public int? TotalScore { get; set; }
    }
}
