﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EfLearning.Business.Responses
{
    public class CountResponse
    {
        public int Count { get; set; }
    }
}
