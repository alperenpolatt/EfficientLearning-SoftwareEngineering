﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EfLearning.Business.Responses
{
    public class HintResponse
    {
        public string Hint { get; set; }
    }
}
