﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EfLearning.Business.Responses
{
    public class LevelResponse
    {
        public int Id { get; set; }
        public int Level { get; set; }
        public string Title { get; set; }
    }
}
