﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EfLearning.Business.Responses
{
    public class NotificationResponse
    {
        public string Message { get; set; }
        public DateTime Date { get; set; }
    }
}
