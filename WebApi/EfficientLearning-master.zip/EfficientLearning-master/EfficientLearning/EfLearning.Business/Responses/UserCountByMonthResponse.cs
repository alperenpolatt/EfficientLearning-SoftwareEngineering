﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EfLearning.Business.Responses
{
    public class UserCountByMonthResponse
    {
        public string MonthName { get; set; }
        public int UserCount { get; set; }
    }
}
