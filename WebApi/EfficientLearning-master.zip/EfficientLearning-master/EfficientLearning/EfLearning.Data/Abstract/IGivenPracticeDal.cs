﻿using EfLearning.Core.Practices;
using System;
using System.Collections.Generic;
using System.Text;

namespace EfLearning.Data.Abstract
{
    public interface IGivenPracticeDal : IRepository<GivenPractice>
    {
    }
}
