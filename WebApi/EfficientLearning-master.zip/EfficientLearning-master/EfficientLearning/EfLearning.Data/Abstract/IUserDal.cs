﻿using EfLearning.Core.Users;
using System;
using System.Collections.Generic;
using System.Text;

namespace EfLearning.Data.Abstract
{
    public interface IUserDal:IRepository<AppUser>
    {
    }
}
