﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EfLearning.Data
{
    public static class CustomRoles
    {
        public const string Admin = nameof(Admin);
        public const string Teacher = nameof(Teacher);
        public const string Student = nameof(Student);
    }
}
