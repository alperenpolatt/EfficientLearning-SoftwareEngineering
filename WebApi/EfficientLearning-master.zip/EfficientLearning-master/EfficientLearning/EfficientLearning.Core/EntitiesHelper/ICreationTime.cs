﻿using System;

namespace EfLearning.Core.EntitiesHelper
{
    public interface ICreationTime
    {
        DateTime CreationTime { get; set; }
    }
}
