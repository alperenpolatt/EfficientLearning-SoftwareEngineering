﻿namespace EfLearning.Core.EntitiesHelper
{
    public interface IPassivable
    {
        bool IsActive { get; set; }
    }
}
