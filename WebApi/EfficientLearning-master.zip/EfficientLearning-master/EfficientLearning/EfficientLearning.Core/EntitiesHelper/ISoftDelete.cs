﻿namespace EfLearning.Core.EntitiesHelper
{
    public interface ISoftDelete
    {
        bool IsDeleted { get; set; }
    }
}
