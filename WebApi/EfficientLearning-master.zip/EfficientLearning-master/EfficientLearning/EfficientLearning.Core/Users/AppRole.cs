﻿using Microsoft.AspNetCore.Identity;

namespace EfLearning.Core.Users
{
    public class AppRole : IdentityRole<int>
    {
    }
}
