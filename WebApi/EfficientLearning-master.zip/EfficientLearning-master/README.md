# Efficient Learning
Efficient Learnig is a graduation project which you can learn the fundemental of programming
